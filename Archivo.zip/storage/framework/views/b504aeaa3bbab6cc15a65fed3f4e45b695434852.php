<?php $__env->startSection('content'); ?>
<section class="deporte section container">
    <h1 class="text-center"> DEPORTE:</h1>
        <section class="section">
            <article><h4>1)	ASOCIACIÓN DEPORTIVA: </h4><p>Crear una verdadera asociación deportiva en la que se busque mejorar las condiciones de la práctica del deporte; así como buscar la creación de escuelitas en las diversas disciplinas fomentando en nuestros hijos el amor al deporte como una forma de vida saludable.</p></article>

        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('propuesta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/martinez/Sites/Laravel/ciceronalfaro/resources/views/propuestas/deporte.blade.php ENDPATH**/ ?>